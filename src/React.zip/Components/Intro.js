import React, { Component } from "react";

class HelloWorld extends Component {
  state = {};
  render() {
    return;
  }
}

export default HelloWorld;
