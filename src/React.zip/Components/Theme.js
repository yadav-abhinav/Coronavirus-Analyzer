export const lightTheme = {
  body: "#d8f5ff",
  text: "#363537",
  toggleBorder: "#FFF",
  background: "#363537",
};
export const darkTheme = {
  body: "#0a0a0a",
  text: "#e1e1ff",
  toggleBorder: "#6B8096",
  background: "#999",
};
